package com.leedit.senareply;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class StatsStore {
    static final String DETECTED = "detected";
    static final String MATCHED = "matched";
    static final String REPLIED = "replied";
    static final String BLOCKED = "blocked";
    static final String FAILED = "failed";

    static final class Snapshot {
        final int detectedToday, matchedToday, repliedToday, blockedToday, failedToday;
        final long detectedTotal, matchedTotal, repliedTotal, blockedTotal, failedTotal;
        Snapshot(int d, int m, int r, int b, int f, long dt, long mt, long rt, long bt, long ft) {
            detectedToday=d; matchedToday=m; repliedToday=r; blockedToday=b; failedToday=f;
            detectedTotal=dt; matchedTotal=mt; repliedTotal=rt; blockedTotal=bt; failedTotal=ft;
        }
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private static synchronized void roll(Context c) {
        SharedPreferences p = RuleStore.prefs(c);
        String now = today();
        if (!now.equals(p.getString("stats_day", ""))) {
            p.edit().putString("stats_day", now)
                    .putInt("stats_today_detected",0)
                    .putInt("stats_today_matched",0)
                    .putInt("stats_today_replied",0)
                    .putInt("stats_today_blocked",0)
                    .putInt("stats_today_failed",0).apply();
        }
    }

    static synchronized void increment(Context c, String key) {
        roll(c);
        SharedPreferences p = RuleStore.prefs(c);
        String todayKey = "stats_today_" + key;
        String totalKey = "stats_total_" + key;
        p.edit()
                .putInt(todayKey, p.getInt(todayKey, 0) + 1)
                .putLong(totalKey, p.getLong(totalKey, 0L) + 1L)
                .apply();
    }

    static synchronized Snapshot snapshot(Context c) {
        roll(c);
        SharedPreferences p = RuleStore.prefs(c);
        return new Snapshot(
                p.getInt("stats_today_detected",0), p.getInt("stats_today_matched",0),
                p.getInt("stats_today_replied",0), p.getInt("stats_today_blocked",0),
                p.getInt("stats_today_failed",0),
                p.getLong("stats_total_detected",0), p.getLong("stats_total_matched",0),
                p.getLong("stats_total_replied",0), p.getLong("stats_total_blocked",0),
                p.getLong("stats_total_failed",0));
    }
}
