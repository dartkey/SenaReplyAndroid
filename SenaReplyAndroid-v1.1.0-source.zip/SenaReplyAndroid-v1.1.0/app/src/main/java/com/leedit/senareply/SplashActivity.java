package com.leedit.senareply;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

public class SplashActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.NAVY);
        ImageView img = new ImageView(this);
        img.setImageResource(com.leedit.senareply.R.drawable.splash_screen);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        setContentView(img);
        new Handler().postDelayed(() -> {
            boolean onboarded = RuleStore.prefs(this).getBoolean("onboarded", false);
            startActivity(new Intent(this, onboarded ? MainActivity.class : OnboardingActivity.class));
            finish();
        }, 1400);
    }
}
