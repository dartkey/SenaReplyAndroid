package com.leedit.senareply;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

final class SafetyStore {
    private static final String KEY = "safety_reply_log";
    private static final long HOUR = 60L * 60L * 1000L;

    static final class Decision {
        final boolean allowed;
        final String reason;
        Decision(boolean allowed, String reason) { this.allowed=allowed; this.reason=reason; }
    }

    static synchronized Decision canReply(Context c, String conversationKey, int cooldownSeconds, int senderHourlyLimit, String incoming) {
        long now = System.currentTimeMillis();
        JSONArray kept = new JSONArray();
        int senderCount = 0;
        int globalCount = 0;
        long latestForSender = 0L;
        String latestReply = "";
        try {
            JSONArray a = new JSONArray(RuleStore.prefs(c).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long t = o.optLong("time",0);
                if (now - t > HOUR) continue;
                kept.put(o);
                globalCount++;
                if (conversationKey.equals(o.optString("key"))) {
                    senderCount++;
                    if (t > latestForSender) {
                        latestForSender = t;
                        latestReply = o.optString("reply","");
                    }
                }
            }
            RuleStore.prefs(c).edit().putString(KEY, kept.toString()).apply();
        } catch (Exception ignored) {}

        if (!latestReply.isEmpty() && latestReply.trim().equalsIgnoreCase(incoming == null ? "" : incoming.trim()))
            return new Decision(false, "loop");
        if (latestForSender > 0 && now - latestForSender < Math.max(0,cooldownSeconds) * 1000L)
            return new Decision(false, "cooldown");
        if (senderCount >= Math.max(1,senderHourlyLimit))
            return new Decision(false, "sender_limit");
        if (globalCount >= RuleStore.globalHourlyLimit(c))
            return new Decision(false, "global_limit");
        return new Decision(true, "ok");
    }

    static synchronized void recordReply(Context c, String conversationKey, String reply) {
        long now = System.currentTimeMillis();
        JSONArray next = new JSONArray();
        try {
            JSONArray a = new JSONArray(RuleStore.prefs(c).getString(KEY, "[]"));
            JSONObject n = new JSONObject();
            n.put("key", conversationKey);
            n.put("reply", reply == null ? "" : reply);
            n.put("time", now);
            next.put(n);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (now - o.optLong("time",0) <= HOUR) next.put(o);
                if (next.length() >= 500) break;
            }
            RuleStore.prefs(c).edit().putString(KEY, next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static synchronized void clear(Context c) {
        RuleStore.prefs(c).edit().putString(KEY, "[]").apply();
    }
}
