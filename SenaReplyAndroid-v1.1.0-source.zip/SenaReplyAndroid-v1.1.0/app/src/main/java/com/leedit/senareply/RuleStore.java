package com.leedit.senareply;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

final class RuleStore {
    private static final String PREFS = "sena_reply_prefs";
    static final String KEY_RULES = "rules_json";
    static final String KEY_HISTORY = "history_json";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static List<Rule> load(Context c) {
        ArrayList<Rule> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString(KEY_RULES, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Rule.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    static Rule find(Context c, String id) {
        if (id == null) return null;
        for (Rule r : load(c)) if (id.equals(r.id)) return r;
        return null;
    }

    static void save(Context c, List<Rule> rules) {
        JSONArray a = new JSONArray();
        for (Rule r : rules) {
            try { a.put(r.toJson()); } catch (Exception ignored) {}
        }
        prefs(c).edit().putString(KEY_RULES, a.toString()).apply();
    }

    static void add(Context c, Rule rule) {
        List<Rule> rules = load(c);
        rules.add(rule);
        save(c, rules);
    }

    static void upsert(Context c, Rule rule) {
        List<Rule> rules = load(c);
        for (int i = 0; i < rules.size(); i++) {
            if (rules.get(i).id.equals(rule.id)) {
                rules.set(i, rule);
                save(c, rules);
                return;
            }
        }
        rules.add(rule);
        save(c, rules);
    }

    static void delete(Context c, String id) {
        List<Rule> rules = load(c);
        for (int i = rules.size() - 1; i >= 0; i--) if (rules.get(i).id.equals(id)) rules.remove(i);
        save(c, rules);
    }

    static boolean autoReplyEnabled(Context c) {
        return prefs(c).getBoolean("auto_reply_enabled", true);
    }

    static void setAutoReplyEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("auto_reply_enabled", enabled).apply();
    }

    static boolean whatsappEnabled(Context c) {
        return prefs(c).getBoolean("whatsapp_enabled", true);
    }

    static void setWhatsappEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("whatsapp_enabled", enabled).apply();
    }

    static boolean whatsappBusinessEnabled(Context c) {
        return prefs(c).getBoolean("whatsapp_business_enabled", true);
    }

    static void setWhatsappBusinessEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("whatsapp_business_enabled", enabled).apply();
    }

    static boolean historyEnabled(Context c) {
        return prefs(c).getBoolean("history_enabled", true);
    }

    static void setHistoryEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("history_enabled", enabled).apply();
    }

    static int globalHourlyLimit(Context c) {
        return Math.max(10, prefs(c).getInt("global_hourly_limit", 120));
    }
}
