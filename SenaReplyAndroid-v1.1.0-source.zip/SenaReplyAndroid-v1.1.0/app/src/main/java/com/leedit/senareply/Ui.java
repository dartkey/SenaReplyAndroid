package com.leedit.senareply;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int NAVY = Color.rgb(2, 18, 59);
    static final int NAVY2 = Color.rgb(4, 35, 105);
    static final int BLUE = Color.rgb(18, 130, 255);
    static final int CYAN = Color.rgb(57, 211, 255);
    static final int WHITE = Color.WHITE;
    static final int MUTED = Color.rgb(188, 206, 239);
    static final int GREEN = Color.rgb(40, 209, 124);
    static final int RED = Color.rgb(255, 105, 119);
    static final int YELLOW = Color.rgb(255, 221, 84);

    private Ui() {}

    static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable background() {
        return new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(2, 22, 75), Color.rgb(5, 61, 180), Color.rgb(1, 15, 52)});
    }

    static GradientDrawable card(Context c) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(21, 67, 150), Color.rgb(8, 35, 93)});
        g.setCornerRadius(dp(c, 19));
        g.setStroke(dp(c, 1), Color.rgb(69, 138, 235));
        return g;
    }

    static GradientDrawable buttonBg(Context c) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.rgb(15, 103, 244), Color.rgb(28, 176, 255)});
        g.setCornerRadius(dp(c, 16));
        g.setStroke(dp(c, 1), CYAN);
        return g;
    }

    static GradientDrawable secondaryButtonBg(Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(12, 44, 109));
        g.setCornerRadius(dp(c, 16));
        g.setStroke(dp(c, 1), Color.rgb(79, 129, 206));
        return g;
    }

    static GradientDrawable chip(Context c, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(55, Color.red(color), Color.green(color), Color.blue(color)));
        g.setCornerRadius(dp(c, 30));
        g.setStroke(dp(c, 1), color);
        return g;
    }

    static TextView title(Context c, String s, float sp) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(WHITE);
        t.setTextSize(sp);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        return t;
    }

    static TextView text(Context c, String s, float sp) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(MUTED);
        t.setTextSize(sp);
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    static TextView status(Context c, String s, int color) {
        TextView t = text(c, s, 12);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c,10),dp(c,5),dp(c,10),dp(c,5));
        t.setBackground(chip(c,color));
        return t;
    }

    static Button button(Context c, String label) {
        Button b = new Button(c);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(WHITE);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(buttonBg(c));
        b.setPadding(dp(c, 14), dp(c, 7), dp(c, 14), dp(c, 7));
        return b;
    }

    static Button secondaryButton(Context c, String label) {
        Button b = button(c,label);
        b.setBackground(secondaryButtonBg(c));
        return b;
    }

    static LinearLayout cardLayout(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        l.setBackground(card(c));
        return l;
    }

    static void margins(View v, int l, int t, int r, int b) {
        ViewGroup.LayoutParams raw = v.getLayoutParams();
        if (raw instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) raw;
            Context c = v.getContext();
            p.setMargins(dp(c,l), dp(c,t), dp(c,r), dp(c,b));
            v.setLayoutParams(p);
        }
    }
}
