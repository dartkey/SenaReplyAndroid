package com.leedit.senareply;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class OnboardingActivity extends Activity {
    private int page = 0;
    private LinearLayout body;
    private Button next;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.NAVY);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(Ui.background());
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 24), Ui.dp(this, 26), Ui.dp(this, 24), Ui.dp(this, 30));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
        showPage();
        setContentView(scroll);
    }

    private void clear() { body.removeAllViews(); }

    private void showPage() {
        clear();
        if (page == 0) developerPage();
        else if (page == 1) aboutPage();
        else if (page == 2) supportPage();
        else setupPage();
    }

    private void addNext(String label) {
        next = Ui.button(this, label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Ui.dp(this, 56));
        p.topMargin = Ui.dp(this, 24);
        body.addView(next, p);
        next.setOnClickListener(v -> { page++; showPage(); });
    }

    private void developerPage() {
        body.addView(Ui.title(this, "Meet the Developer", 22));
        ImageView photo = new ImageView(this);
        photo.setImageResource(R.drawable.martin_foli);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientCircle.make(photo, this);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(this, 184), Ui.dp(this, 184));
        ip.gravity = Gravity.CENTER_HORIZONTAL; ip.topMargin = Ui.dp(this, 22);
        body.addView(photo, ip);
        TextView name = Ui.title(this, "Martin Foli", 27);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1,-2); np.topMargin=Ui.dp(this,18); body.addView(name,np);
        TextView roles = Ui.text(this, "Electrical/Electronic Engineer\nProgrammer • Graphic Designer", 15);
        roles.setGravity(Gravity.CENTER_HORIZONTAL); body.addView(roles);

        LinearLayout card = Ui.cardLayout(this);
        TextView bio = Ui.text(this,
                "Hi, I’m Martin Foli. I’m an Electrical/Electronic Engineer and a graduate of Ho Technical University (HTU). I also studied BSc Applied Technology at BYU–Idaho.\n\n" +
                "Beyond engineering, I’m a self-taught programmer and graphic designer with a strong interest in practical technology, problem-solving and digital products.", 15);
        card.addView(bio);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=Ui.dp(this,22); body.addView(card,cp);
        addNext("Continue  →");
    }

    private void aboutPage() {
        body.addView(Ui.title(this, "About Sena Reply", 24));
        LinearLayout card = Ui.cardLayout(this);
        card.addView(Ui.title(this, "Smart replies. Always connected.", 18));
        TextView t = Ui.text(this,
                "Sena Reply was created to make WhatsApp automation simple, useful and freely accessible.\n\n" +
                "Whether you’re busy, working, studying or away, Sena Reply can respond to incoming messages using rules you control.\n\n" +
                "Privacy first: fixed-rule processing and reply history stay on your device unless you later enable an external integration.", 15);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,-2); tp.topMargin=Ui.dp(this,14); card.addView(t,tp);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=Ui.dp(this,22); body.addView(card,cp);
        addNext("Next  →");
    }

    private void supportPage() {
        body.addView(Ui.title(this, "♡  Support the Project", 24));
        TextView intro = Ui.text(this,
                "Sena Reply is free to use. If you find it helpful and would like to support continued development, you can voluntarily send any amount via Mobile Money.", 15);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,-2); ip.topMargin=Ui.dp(this,18); body.addView(intro,ip);

        LinearLayout card = Ui.cardLayout(this);
        TextView momoLabel = Ui.title(this, "MTN MoMo", 15); momoLabel.setTextColor(Color.rgb(255,220,60)); card.addView(momoLabel);
        card.addView(Ui.title(this, "Martin Foli", 22));
        card.addView(Ui.title(this, "0546757518", 28));
        Button copy = Ui.button(this, "Copy MoMo Number");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,Ui.dp(this,52)); bp.topMargin=Ui.dp(this,16); card.addView(copy,bp);
        copy.setOnClickListener(v -> copy("0546757518", "MoMo number copied"));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=Ui.dp(this,24); body.addView(card,cp);

        LinearLayout email = Ui.cardLayout(this);
        email.addView(Ui.title(this, "Contact Developer", 17));
        TextView em = Ui.text(this, "leeditgraphics@gmail.com", 16); em.setGravity(Gravity.CENTER); email.addView(em);
        Button mail = Ui.button(this, "Email Martin");
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1,Ui.dp(this,52)); mp.topMargin=Ui.dp(this,14); email.addView(mail,mp);
        mail.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:leeditgraphics@gmail.com"));
            i.putExtra(Intent.EXTRA_SUBJECT, "Sena Reply Support");
            try { startActivity(i); } catch (Exception e) { copy("leeditgraphics@gmail.com", "Email copied"); }
        });
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,-2); ep.topMargin=Ui.dp(this,14); body.addView(email,ep);
        addNext("Maybe Later / Continue  →");
    }

    private void setupPage() {
        body.addView(Ui.title(this, "Let’s Get You Set Up", 24));
        addSetupCard("1", "Notification Access", "Required to detect WhatsApp notifications and use Android's Reply action.", v -> {
            try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
        });
        addSetupCard("2", "Battery Settings", "Allow Sena Reply to keep working reliably in the background.", v -> startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        addSetupCard("3", "WhatsApp Apps", "Version 1 supports WhatsApp and WhatsApp Business. Both are enabled by default.", null);
        addSetupCard("4", "Create a Test Rule", "After setup, create a simple rule such as Hello → Hi! Thanks for messaging me.", null);
        Button get = Ui.button(this, "Get Started  →");
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); gp.topMargin=Ui.dp(this,26); body.addView(get,gp);
        get.setOnClickListener(v -> {
            RuleStore.prefs(this).edit().putBoolean("onboarded", true).apply();
            startActivity(new Intent(this, MainActivity.class)); finish();
        });
        TextView note = Ui.text(this, "On some sideloaded Android 13+ phones, Notification Access may require App info → ⋮ → Allow restricted settings first.", 12);
        note.setGravity(Gravity.CENTER); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=Ui.dp(this,15); body.addView(note,np);
    }

    private void addSetupCard(String n, String title, String desc, View.OnClickListener click) {
        LinearLayout card = Ui.cardLayout(this);
        TextView h = Ui.title(this, n + "   " + title, 17); h.setGravity(Gravity.LEFT); card.addView(h);
        TextView d = Ui.text(this, desc, 13); LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1,-2); dp.topMargin=Ui.dp(this,8); card.addView(d,dp);
        if (click != null) { card.setClickable(true); card.setOnClickListener(click); }
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.topMargin=Ui.dp(this,14); body.addView(card,cp);
    }

    private void copy(String value, String toast) {
        ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Sena Reply", value)); Toast.makeText(this,toast,Toast.LENGTH_SHORT).show();
    }

    private static final class GradientCircle {
        static void make(ImageView v, Context c) {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(Ui.NAVY2); g.setStroke(Ui.dp(c,3),Ui.CYAN); v.setBackground(g); v.setClipToOutline(true);
        }
    }
}
