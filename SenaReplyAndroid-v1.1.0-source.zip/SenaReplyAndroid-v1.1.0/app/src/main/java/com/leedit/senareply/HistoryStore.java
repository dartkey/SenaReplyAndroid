package com.leedit.senareply;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;

final class HistoryStore {
    private static final int MAX = 300;

    static void add(Context c, String sender, String conversation, String message, String reply, String app) {
        if (!RuleStore.historyEnabled(c)) return;
        try {
            JSONArray old = new JSONArray(RuleStore.prefs(c).getString(RuleStore.KEY_HISTORY, "[]"));
            JSONArray next = new JSONArray();
            JSONObject o = new JSONObject();
            o.put("sender", sender);
            o.put("conversation", conversation);
            o.put("message", message);
            o.put("reply", reply);
            o.put("app", app);
            o.put("time", System.currentTimeMillis());
            next.put(o);
            for (int i = 0; i < old.length() && i < MAX - 1; i++) next.put(old.getJSONObject(i));
            RuleStore.prefs(c).edit().putString(RuleStore.KEY_HISTORY, next.toString()).apply();
        } catch (Exception ignored) {}
    }

    static JSONArray load(Context c) {
        try { return new JSONArray(RuleStore.prefs(c).getString(RuleStore.KEY_HISTORY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    static void clear(Context c) {
        RuleStore.prefs(c).edit().putString(RuleStore.KEY_HISTORY, "[]").apply();
    }
}
