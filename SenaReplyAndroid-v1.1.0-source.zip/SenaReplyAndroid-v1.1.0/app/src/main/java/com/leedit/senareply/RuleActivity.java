package com.leedit.senareply;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;

public class RuleActivity extends Activity {
    private EditText trigger, reply, targets, excludes, delay, cooldown, hourlyLimit;
    private Spinner match, scope;
    private Switch active, schedule;
    private Button startTime, endTime;
    private final CheckBox[] days = new CheckBox[7];
    private int startMinutes = 0;
    private int endMinutes = 1439;
    private Rule editing;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.NAVY);
        String id = getIntent().getStringExtra("rule_id");
        editing = RuleStore.find(this, id);
        render();
    }

    private void render() {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        s.setBackground(Ui.background());
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(Ui.dp(this,20),Ui.dp(this,24),Ui.dp(this,20),Ui.dp(this,30));
        s.addView(r,new ScrollView.LayoutParams(-1,-2));

        TextView title = Ui.title(this, editing == null ? "Create Rule" : "Edit Rule", 25);
        r.addView(title);

        addLabel(r, "1. When I receive");
        trigger = input("e.g. Hello, price, *order*");
        r.addView(trigger, new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        addSmallLabel(r, "Match type");
        match = new Spinner(this);
        String[] types={"Exact","Contains","Starts with","Ends with","Wildcard (*)","Regex","Any message"};
        ArrayAdapter<String> ma = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, types);
        match.setAdapter(ma); match.setBackground(Ui.card(this));
        r.addView(match,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        addLabel(r, "2. Reply with");
        reply = input("Type your auto reply message...\nUse || between alternatives for random replies.");
        reply.setMinLines(4); reply.setGravity(Gravity.TOP);
        r.addView(reply,new LinearLayout.LayoutParams(-1,Ui.dp(this,145)));
        TextView variants = Ui.text(this, "Example: Hi 👋 || Hello! Thanks for messaging me.", 12);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1,-2); vp.topMargin=Ui.dp(this,7); r.addView(variants,vp);

        addLabel(r, "3. Who should receive this reply?");
        scope = new Spinner(this);
        String[] scopes={"Everyone","Individual contacts","Groups"};
        ArrayAdapter<String> sa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, scopes);
        scope.setAdapter(sa); scope.setBackground(Ui.card(this));
        r.addView(scope,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));

        targets = input("Optional names, separated by commas (e.g. Kofi, Angela)");
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); tp.topMargin=Ui.dp(this,9); r.addView(targets,tp);
        excludes = input("Never reply to these names (optional)");
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); ep.topMargin=Ui.dp(this,9); r.addView(excludes,ep);
        TextView targetNote = Ui.text(this, "Names must match how the contact or group appears in the WhatsApp notification. Sena Reply does not read your phone contacts.", 12);
        LinearLayout.LayoutParams tnp = new LinearLayout.LayoutParams(-1,-2); tnp.topMargin=Ui.dp(this,7); r.addView(targetNote,tnp);

        addLabel(r, "4. Timing & safety");
        LinearLayout timing = Ui.cardLayout(this);
        timing.addView(Ui.text(this, "Delay before replying (seconds)", 13));
        delay = numberInput("0"); timing.addView(delay,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        timing.addView(Ui.text(this, "Cooldown per conversation (seconds)", 13));
        cooldown = numberInput("30"); timing.addView(cooldown,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        timing.addView(Ui.text(this, "Maximum replies to one conversation per hour", 13));
        hourlyLimit = numberInput("10"); timing.addView(hourlyLimit,new LinearLayout.LayoutParams(-1,Ui.dp(this,52)));
        LinearLayout.LayoutParams tip = new LinearLayout.LayoutParams(-1,-2); tip.topMargin=Ui.dp(this,10); r.addView(timing,tip);

        LinearLayout scheduleCard = Ui.cardLayout(this);
        LinearLayout scheduleRow = new LinearLayout(this); scheduleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView sh = Ui.title(this, "Schedule", 17); sh.setGravity(Gravity.LEFT);
        scheduleRow.addView(sh,new LinearLayout.LayoutParams(0,-2,1));
        schedule = new Switch(this); scheduleRow.addView(schedule); scheduleCard.addView(scheduleRow);
        TextView sd = Ui.text(this, "Only reply during selected days and times.", 12); scheduleCard.addView(sd);
        LinearLayout timeRow = new LinearLayout(this); timeRow.setOrientation(LinearLayout.HORIZONTAL); timeRow.setWeightSum(2);
        startTime = Ui.button(this,"Start  00:00"); endTime = Ui.button(this,"End  23:59");
        LinearLayout.LayoutParams stb = new LinearLayout.LayoutParams(0,Ui.dp(this,50),1); stb.setMargins(0,Ui.dp(this,10),Ui.dp(this,5),0);
        LinearLayout.LayoutParams etb = new LinearLayout.LayoutParams(0,Ui.dp(this,50),1); etb.setMargins(Ui.dp(this,5),Ui.dp(this,10),0,0);
        timeRow.addView(startTime,stb); timeRow.addView(endTime,etb); scheduleCard.addView(timeRow);
        startTime.setOnClickListener(v -> pickTime(true)); endTime.setOnClickListener(v -> pickTime(false));

        LinearLayout dayRow1 = new LinearLayout(this); dayRow1.setOrientation(LinearLayout.HORIZONTAL); dayRow1.setWeightSum(4);
        LinearLayout dayRow2 = new LinearLayout(this); dayRow2.setOrientation(LinearLayout.HORIZONTAL); dayRow2.setWeightSum(3);
        String[] dayNames={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        for(int i=0;i<7;i++){
            CheckBox cb=new CheckBox(this); cb.setText(dayNames[i]); cb.setTextColor(Ui.WHITE); cb.setChecked(true); days[i]=cb;
            if(i<4) dayRow1.addView(cb,new LinearLayout.LayoutParams(0,-2,1));
            else dayRow2.addView(cb,new LinearLayout.LayoutParams(0,-2,1));
        }
        scheduleCard.addView(dayRow1); scheduleCard.addView(dayRow2);
        LinearLayout.LayoutParams scp = new LinearLayout.LayoutParams(-1,-2); scp.topMargin=Ui.dp(this,12); r.addView(scheduleCard,scp);

        LinearLayout activeCard = Ui.cardLayout(this);
        LinearLayout ar = new LinearLayout(this); ar.setGravity(Gravity.CENTER_VERTICAL);
        TextView ah = Ui.title(this,"Rule is active",17); ah.setGravity(Gravity.LEFT); ar.addView(ah,new LinearLayout.LayoutParams(0,-2,1));
        active = new Switch(this); active.setChecked(true); ar.addView(active); activeCard.addView(ar);
        LinearLayout.LayoutParams acp = new LinearLayout.LayoutParams(-1,-2); acp.topMargin=Ui.dp(this,12); r.addView(activeCard,acp);

        Button save = Ui.button(this, editing == null ? "✓  Save Rule" : "✓  Update Rule");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); sp.topMargin=Ui.dp(this,22); r.addView(save,sp);
        save.setOnClickListener(v -> saveRule());
        Button cancel = Ui.secondaryButton(this,"Cancel");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,Ui.dp(this,50)); cp.topMargin=Ui.dp(this,12); r.addView(cancel,cp); cancel.setOnClickListener(v->finish());

        if (editing != null) populate(editing);
        updateScheduleVisibility();
        schedule.setOnCheckedChangeListener((b,on)->updateScheduleVisibility());
        scope.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id){
                targets.setVisibility(pos==0 ? View.GONE : View.VISIBLE);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        setContentView(s);
    }

    private void populate(Rule rule) {
        trigger.setText(rule.trigger); reply.setText(rule.reply); active.setChecked(rule.active);
        String[] values={"exact","contains","starts","ends","wildcard","regex","any"};
        for(int i=0;i<values.length;i++) if(values[i].equals(rule.matchType)) match.setSelection(i);
        if("contacts".equals(rule.scope)) scope.setSelection(1); else if("groups".equals(rule.scope)) scope.setSelection(2); else scope.setSelection(0);
        targets.setText(rule.targets); excludes.setText(rule.excludedTargets);
        delay.setText(String.valueOf(rule.delaySeconds)); cooldown.setText(String.valueOf(rule.cooldownSeconds)); hourlyLimit.setText(String.valueOf(rule.maxRepliesPerHour));
        schedule.setChecked(rule.scheduleEnabled); startMinutes=rule.startMinutes; endMinutes=rule.endMinutes;
        updateTimeLabels();
        for(int i=0;i<7;i++) days[i].setChecked((rule.daysMask & (1<<i)) != 0);
    }

    private void saveRule() {
        String tr=trigger.getText().toString().trim(); String rp=reply.getText().toString().trim();
        int mpos=match.getSelectedItemPosition(); String[] mts={"exact","contains","starts","ends","wildcard","regex","any"}; String mt=mts[Math.max(0,Math.min(mpos,mts.length-1))];
        if(rp.isEmpty() || (!"any".equals(mt) && tr.isEmpty())) { Toast.makeText(this,"Enter the trigger and reply",Toast.LENGTH_SHORT).show(); return; }
        int spos=scope.getSelectedItemPosition(); String sc=spos==1?"contacts":spos==2?"groups":"everyone";
        int mask=0; for(int i=0;i<7;i++) if(days[i].isChecked()) mask|=(1<<i);
        if(schedule.isChecked() && mask==0){Toast.makeText(this,"Select at least one schedule day",Toast.LENGTH_SHORT).show();return;}
        String id=editing==null?UUID.randomUUID().toString():editing.id;
        Rule rule=new Rule(id,tr,rp,mt,active.isChecked(),sc,targets.getText().toString().trim(),excludes.getText().toString().trim(),
                schedule.isChecked(),startMinutes,endMinutes,mask==0?Rule.ALL_DAYS_MASK:mask,
                parseInt(delay,0,0,600),parseInt(cooldown,30,0,86400),parseInt(hourlyLimit,10,1,1000));
        if(!rule.isRegexValid()){Toast.makeText(this,"The regular expression is invalid",Toast.LENGTH_LONG).show();return;}
        RuleStore.upsert(this,rule); Toast.makeText(this,editing==null?"Rule saved":"Rule updated",Toast.LENGTH_SHORT).show(); finish();
    }

    private int parseInt(EditText e,int fallback,int min,int max){
        try{return Math.max(min,Math.min(max,Integer.parseInt(e.getText().toString().trim())));}catch(Exception x){return fallback;}
    }

    private void pickTime(boolean start){
        int current=start?startMinutes:endMinutes; int h=current/60,m=current%60;
        new TimePickerDialog(this,(v,hour,minute)->{if(start)startMinutes=hour*60+minute;else endMinutes=hour*60+minute;updateTimeLabels();},h,m,true).show();
    }

    private void updateTimeLabels(){ startTime.setText("Start  "+formatTime(startMinutes)); endTime.setText("End  "+formatTime(endMinutes)); }
    private String formatTime(int minutes){return String.format(java.util.Locale.US,"%02d:%02d",minutes/60,minutes%60);}
    private void updateScheduleVisibility(){ int vis=schedule.isChecked()?View.VISIBLE:View.GONE; startTime.setVisibility(vis); endTime.setVisibility(vis); for(CheckBox d:days)d.setVisibility(vis); }

    private void addLabel(LinearLayout r,String text){TextView t=Ui.text(this,text,14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=Ui.dp(this,20);p.bottomMargin=Ui.dp(this,7);r.addView(t,p);}
    private void addSmallLabel(LinearLayout r,String text){TextView t=Ui.text(this,text,13);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=Ui.dp(this,10);p.bottomMargin=Ui.dp(this,5);r.addView(t,p);}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Ui.MUTED);e.setTextColor(Ui.WHITE);e.setTextSize(15);e.setPadding(Ui.dp(this,15),Ui.dp(this,10),Ui.dp(this,15),Ui.dp(this,10));e.setBackground(Ui.card(this));return e;}
    private EditText numberInput(String hint){EditText e=input(hint);e.setInputType(InputType.TYPE_CLASS_NUMBER);return e;}
}
