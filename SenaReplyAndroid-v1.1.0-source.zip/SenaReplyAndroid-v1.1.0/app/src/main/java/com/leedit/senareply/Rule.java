package com.leedit.senareply;

import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

final class Rule {
    static final int ALL_DAYS_MASK = 0x7F;

    String id;
    String trigger;
    String reply;
    String matchType;
    boolean active;

    String scope;            // everyone | contacts | groups
    String targets;          // comma/newline separated display names
    String excludedTargets;  // comma/newline separated display names

    boolean scheduleEnabled;
    int startMinutes;
    int endMinutes;
    int daysMask;

    int delaySeconds;
    int cooldownSeconds;
    int maxRepliesPerHour;

    Rule(String id, String trigger, String reply, String matchType, boolean active) {
        this(id, trigger, reply, matchType, active,
                "everyone", "", "", false, 0, 1439, ALL_DAYS_MASK,
                0, 30, 10);
    }

    Rule(String id, String trigger, String reply, String matchType, boolean active,
         String scope, String targets, String excludedTargets,
         boolean scheduleEnabled, int startMinutes, int endMinutes, int daysMask,
         int delaySeconds, int cooldownSeconds, int maxRepliesPerHour) {
        this.id = id;
        this.trigger = trigger == null ? "" : trigger;
        this.reply = reply == null ? "" : reply;
        this.matchType = matchType == null ? "exact" : matchType;
        this.active = active;
        this.scope = scope == null ? "everyone" : scope;
        this.targets = targets == null ? "" : targets;
        this.excludedTargets = excludedTargets == null ? "" : excludedTargets;
        this.scheduleEnabled = scheduleEnabled;
        this.startMinutes = clamp(startMinutes, 0, 1439);
        this.endMinutes = clamp(endMinutes, 0, 1439);
        this.daysMask = daysMask == 0 ? ALL_DAYS_MASK : daysMask;
        this.delaySeconds = clamp(delaySeconds, 0, 600);
        this.cooldownSeconds = clamp(cooldownSeconds, 0, 86400);
        this.maxRepliesPerHour = clamp(maxRepliesPerHour, 1, 1000);
    }

    boolean matches(String incoming, String sender, String conversation, boolean isGroup, long now) {
        if (!active || incoming == null || !scheduleAllows(now)) return false;
        if (!scopeAllows(sender, conversation, isGroup)) return false;

        String a = incoming.trim();
        String b = trigger == null ? "" : trigger.trim();
        String al = a.toLowerCase(Locale.ROOT);
        String bl = b.toLowerCase(Locale.ROOT);

        switch (matchType) {
            case "contains": return al.contains(bl);
            case "starts": return al.startsWith(bl);
            case "ends": return al.endsWith(bl);
            case "wildcard": return wildcardMatches(a, b);
            case "regex":
                try { return Pattern.compile(b, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(a).matches(); }
                catch (PatternSyntaxException e) { return false; }
            case "any": return true;
            case "exact":
            default: return al.equals(bl);
        }
    }

    boolean isRegexValid() {
        if (!"regex".equals(matchType)) return true;
        try { Pattern.compile(trigger); return true; }
        catch (PatternSyntaxException e) { return false; }
    }

    String chooseReply() {
        String raw = reply == null ? "" : reply.trim();
        if (!raw.contains("||")) return raw;
        String[] chunks = raw.split("\\|\\|");
        ArrayList<String> options = new ArrayList<>();
        for (String c : chunks) if (!c.trim().isEmpty()) options.add(c.trim());
        if (options.isEmpty()) return raw;
        return options.get(new Random().nextInt(options.size()));
    }

    private boolean scopeAllows(String sender, String conversation, boolean isGroup) {
        String key = isGroup ? safe(conversation) : safe(sender);
        if (matchesAnyName(key, excludedTargets)) return false;

        if ("groups".equals(scope)) {
            if (!isGroup) return false;
            return targets.trim().isEmpty() || matchesAnyName(safe(conversation), targets);
        }
        if ("contacts".equals(scope)) {
            if (isGroup) return false;
            return targets.trim().isEmpty() || matchesAnyName(safe(sender), targets);
        }
        return true;
    }

    private boolean scheduleAllows(long now) {
        if (!scheduleEnabled) return true;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(now);
        int minute = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
        int dayIndex = c.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY; // 0..6

        if (startMinutes <= endMinutes) {
            return daySelected(dayIndex) && minute >= startMinutes && minute <= endMinutes;
        }

        // Overnight schedule, e.g. 22:00 → 06:00.
        if (minute >= startMinutes) return daySelected(dayIndex);
        int previous = (dayIndex + 6) % 7;
        return minute <= endMinutes && daySelected(previous);
    }

    private boolean daySelected(int dayIndex) {
        return (daysMask & (1 << dayIndex)) != 0;
    }

    private static boolean wildcardMatches(String input, String wildcard) {
        StringBuilder regex = new StringBuilder("^");
        String[] parts = wildcard.split("\\*", -1);
        for (int i = 0; i < parts.length; i++) {
            regex.append(Pattern.quote(parts[i]));
            if (i < parts.length - 1) regex.append(".*");
        }
        regex.append("$");
        return Pattern.compile(regex.toString(), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.DOTALL)
                .matcher(input).matches();
    }

    private static boolean matchesAnyName(String actual, String list) {
        String norm = normalize(actual);
        if (norm.isEmpty() || list == null || list.trim().isEmpty()) return false;
        for (String item : splitNames(list)) {
            if (norm.equals(normalize(item))) return true;
        }
        return false;
    }

    private static List<String> splitNames(String value) {
        ArrayList<String> out = new ArrayList<>();
        if (value == null) return out;
        for (String s : value.split("[,\\n;]")) if (!s.trim().isEmpty()) out.add(s.trim());
        return out;
    }

    private static String normalize(String s) {
        return safe(s).trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static int clamp(int n, int min, int max) { return Math.max(min, Math.min(max, n)); }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("trigger", trigger);
        o.put("reply", reply);
        o.put("matchType", matchType);
        o.put("active", active);
        o.put("scope", scope);
        o.put("targets", targets);
        o.put("excludedTargets", excludedTargets);
        o.put("scheduleEnabled", scheduleEnabled);
        o.put("startMinutes", startMinutes);
        o.put("endMinutes", endMinutes);
        o.put("daysMask", daysMask);
        o.put("delaySeconds", delaySeconds);
        o.put("cooldownSeconds", cooldownSeconds);
        o.put("maxRepliesPerHour", maxRepliesPerHour);
        return o;
    }

    static Rule fromJson(JSONObject o) {
        return new Rule(
                o.optString("id"),
                o.optString("trigger"),
                o.optString("reply"),
                o.optString("matchType", "exact"),
                o.optBoolean("active", true),
                o.optString("scope", "everyone"),
                o.optString("targets", ""),
                o.optString("excludedTargets", ""),
                o.optBoolean("scheduleEnabled", false),
                o.optInt("startMinutes", 0),
                o.optInt("endMinutes", 1439),
                o.optInt("daysMask", ALL_DAYS_MASK),
                o.optInt("delaySeconds", 0),
                o.optInt("cooldownSeconds", 30),
                o.optInt("maxRepliesPerHour", 10));
    }
}
