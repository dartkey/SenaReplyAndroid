package com.leedit.senareply;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SenaNotificationService extends NotificationListenerService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, Long> recentNotifications = new HashMap<>();
    private static final long DUPLICATE_WINDOW_MS = 2500L;

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!RuleStore.autoReplyEnabled(this)) return;
        String pkg = sbn.getPackageName();
        boolean isBusiness = "com.whatsapp.w4b".equals(pkg);
        if (!("com.whatsapp".equals(pkg) || isBusiness)) return;
        if (isBusiness && !RuleStore.whatsappBusinessEnabled(this)) return;
        if (!isBusiness && !RuleStore.whatsappEnabled(this)) return;

        Notification n = sbn.getNotification();
        if (n == null) return;

        MessageInfo info = extractMessage(n);
        if (info.message.isEmpty()) return;
        StatsStore.increment(this, StatsStore.DETECTED);

        String app = isBusiness ? "WhatsApp Business" : "WhatsApp";
        String conversationKey = pkg + "|" + normalize(info.isGroup ? info.conversation : info.sender);
        String signature = conversationKey + "|" + normalize(info.message);
        long now = System.currentTimeMillis();
        synchronized (recentNotifications) {
            Long prior = recentNotifications.get(signature);
            if (prior != null && now - prior < DUPLICATE_WINDOW_MS) return;
            recentNotifications.put(signature, now);
            if (recentNotifications.size() > 150) {
                recentNotifications.entrySet().removeIf(e -> now - e.getValue() > 60_000L);
            }
        }

        List<Rule> rules = RuleStore.load(this);
        for (Rule rule : rules) {
            if (!rule.matches(info.message, info.sender, info.conversation, info.isGroup, now)) continue;
            StatsStore.increment(this, StatsStore.MATCHED);
            String reply = rule.chooseReply();
            ReplyAction action = findReplyAction(n);
            if (action == null) {
                StatsStore.increment(this, StatsStore.FAILED);
                return;
            }
            long delayMs = Math.max(0, rule.delaySeconds) * 1000L;
            handler.postDelayed(() -> attemptReply(action, rule, info, reply, app, conversationKey), delayMs);
            break;
        }
    }

    private void attemptReply(ReplyAction action, Rule rule, MessageInfo info, String reply, String app, String conversationKey) {
        SafetyStore.Decision d = SafetyStore.canReply(this, conversationKey, rule.cooldownSeconds, rule.maxRepliesPerHour, info.message);
        if (!d.allowed) {
            StatsStore.increment(this, StatsStore.BLOCKED);
            return;
        }
        if (sendRemoteReply(action, reply)) {
            SafetyStore.recordReply(this, conversationKey, reply);
            StatsStore.increment(this, StatsStore.REPLIED);
            HistoryStore.add(this,
                    info.sender.isEmpty() ? (info.isGroup ? info.conversation : app) : info.sender,
                    info.conversation,
                    info.message,
                    reply,
                    app);
        } else {
            StatsStore.increment(this, StatsStore.FAILED);
        }
    }

    private ReplyAction findReplyAction(Notification n) {
        if (n.actions == null) return null;
        for (Notification.Action action : n.actions) {
            RemoteInput[] remoteInputs = action.getRemoteInputs();
            if (remoteInputs == null || remoteInputs.length == 0 || action.actionIntent == null) continue;
            boolean freeForm = false;
            for (RemoteInput input : remoteInputs) if (input.getAllowFreeFormInput()) freeForm = true;
            if (freeForm) return new ReplyAction(action.actionIntent, remoteInputs);
        }
        return null;
    }

    private boolean sendRemoteReply(ReplyAction action, String reply) {
        try {
            Intent intent = new Intent();
            Bundle results = new Bundle();
            for (RemoteInput input : action.inputs) results.putCharSequence(input.getResultKey(), reply);
            RemoteInput.addResultsToIntent(action.inputs, intent, results);
            action.pendingIntent.send(this, 0, intent);
            return true;
        } catch (PendingIntent.CanceledException | RuntimeException ignored) {
            return false;
        }
    }

    private MessageInfo extractMessage(Notification n) {
        Bundle e = n.extras == null ? new Bundle() : n.extras;
        String title = text(e.getCharSequence(Notification.EXTRA_TITLE));
        String message = text(e.getCharSequence(Notification.EXTRA_TEXT));
        String conversation = text(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
        boolean isGroup = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false) || !conversation.isEmpty();
        String sender = title;

        try {
            Parcelable[] parcels = e.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (parcels != null && parcels.length > 0) {
                Parcelable p = parcels[parcels.length - 1];
                if (p instanceof Bundle) {
                    Bundle mb = (Bundle) p;
                    String bundleText = text(mb.getCharSequence("text"));
                    String bundleSender = text(mb.getCharSequence("sender"));
                    if (!bundleText.isEmpty()) message = bundleText;
                    if (!bundleSender.isEmpty()) sender = bundleSender;
                }
            }
        } catch (Exception ignored) {}

        if (isGroup) {
            if (conversation.isEmpty()) conversation = title;
            if (sender.equals(conversation) || sender.isEmpty()) {
                int colon = message.indexOf(':');
                if (colon > 0 && colon < 60) {
                    String possible = message.substring(0, colon).trim();
                    String rest = message.substring(colon + 1).trim();
                    if (!possible.isEmpty() && !rest.isEmpty()) { sender = possible; message = rest; }
                }
            }
        } else {
            conversation = title;
        }
        return new MessageInfo(sender, conversation, message, isGroup);
    }

    private String text(CharSequence s) { return s == null ? "" : s.toString().trim(); }
    private String normalize(String s) { return s == null ? "" : s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " "); }

    private static final class ReplyAction {
        final PendingIntent pendingIntent;
        final RemoteInput[] inputs;
        ReplyAction(PendingIntent p, RemoteInput[] i) { pendingIntent=p; inputs=i; }
    }

    private static final class MessageInfo {
        final String sender, conversation, message;
        final boolean isGroup;
        MessageInfo(String sender, String conversation, String message, boolean isGroup) {
            this.sender=sender==null?"":sender;
            this.conversation=conversation==null?"":conversation;
            this.message=message==null?"":message;
            this.isGroup=isGroup;
        }
    }
}
