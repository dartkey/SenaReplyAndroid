package com.leedit.senareply;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

final class BackupStore {
    static String exportJson(Context c) throws Exception {
        SharedPreferences p = RuleStore.prefs(c);
        JSONObject root = new JSONObject();
        root.put("app", "Sena Reply");
        root.put("backupVersion", 1);
        root.put("createdAt", System.currentTimeMillis());
        root.put("rules", new JSONArray(p.getString(RuleStore.KEY_RULES, "[]")));
        root.put("history", new JSONArray(p.getString(RuleStore.KEY_HISTORY, "[]")));

        JSONObject settings = new JSONObject();
        settings.put("autoReplyEnabled", RuleStore.autoReplyEnabled(c));
        settings.put("whatsappEnabled", RuleStore.whatsappEnabled(c));
        settings.put("whatsappBusinessEnabled", RuleStore.whatsappBusinessEnabled(c));
        settings.put("historyEnabled", RuleStore.historyEnabled(c));
        settings.put("globalHourlyLimit", RuleStore.globalHourlyLimit(c));
        root.put("settings", settings);
        return root.toString(2);
    }

    static void importJson(Context c, String json) throws Exception {
        JSONObject root = new JSONObject(json);
        if (!"Sena Reply".equals(root.optString("app"))) throw new IllegalArgumentException("Not a Sena Reply backup");
        JSONArray rules = root.optJSONArray("rules");
        JSONArray history = root.optJSONArray("history");
        JSONObject s = root.optJSONObject("settings");
        SharedPreferences.Editor e = RuleStore.prefs(c).edit();
        if (rules != null) e.putString(RuleStore.KEY_RULES, rules.toString());
        if (history != null) e.putString(RuleStore.KEY_HISTORY, history.toString());
        if (s != null) {
            e.putBoolean("auto_reply_enabled", s.optBoolean("autoReplyEnabled", true));
            e.putBoolean("whatsapp_enabled", s.optBoolean("whatsappEnabled", true));
            e.putBoolean("whatsapp_business_enabled", s.optBoolean("whatsappBusinessEnabled", true));
            e.putBoolean("history_enabled", s.optBoolean("historyEnabled", true));
            e.putInt("global_hourly_limit", Math.max(10, s.optInt("globalHourlyLimit", 120)));
        }
        e.apply();
        SafetyStore.clear(c);
    }
}
