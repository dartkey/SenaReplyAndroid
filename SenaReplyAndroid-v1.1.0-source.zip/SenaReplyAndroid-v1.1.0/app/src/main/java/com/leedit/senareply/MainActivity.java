package com.leedit.senareply;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 501;
    private static final int REQ_IMPORT = 502;
    private String currentScreen = "dashboard";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.NAVY);
        getWindow().setNavigationBarColor(Ui.NAVY);
        renderDashboard();
    }

    @Override protected void onResume() {
        super.onResume();
        if ("dashboard".equals(currentScreen) && RuleStore.prefs(this).getBoolean("onboarded",false)) renderDashboard();
    }

    private LinearLayout root(String title) {
        ScrollView s=new ScrollView(this); s.setFillViewport(true); s.setBackground(Ui.background());
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(Ui.dp(this,18),Ui.dp(this,20),Ui.dp(this,18),Ui.dp(this,32));
        s.addView(r,new ScrollView.LayoutParams(-1,-2));
        if(!"Sena Reply".equals(title)){
            Button back=Ui.secondaryButton(this,"←  Dashboard");
            r.addView(back,new LinearLayout.LayoutParams(-1,Ui.dp(this,46)));
            back.setOnClickListener(v->renderDashboard());
            TextView t=Ui.title(this,title,24); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=Ui.dp(this,14);r.addView(t,tp);
        }
        setContentView(s); return r;
    }

    private void renderDashboard() {
        currentScreen="dashboard";
        LinearLayout r=root("Sena Reply");

        LinearLayout header=Ui.cardLayout(this);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon=new ImageView(this);icon.setImageResource(R.mipmap.ic_launcher);top.addView(icon,new LinearLayout.LayoutParams(Ui.dp(this,54),Ui.dp(this,54)));
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.setPadding(Ui.dp(this,12),0,0,0);
        TextView brand=Ui.title(this,"Sena Reply",23);brand.setGravity(Gravity.LEFT);titles.addView(brand);
        TextView sub=Ui.text(this,"Auto Reply for WhatsApp",12);titles.addView(sub);top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(top);
        TextView hello=Ui.text(this,greeting()+" 👋\nLet Sena Reply handle the rest.",14);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=Ui.dp(this,12);header.addView(hello,hp);
        r.addView(header);

        LinearLayout toggleCard=Ui.cardLayout(this); TextView h=Ui.title(this,"Auto Reply",20); h.setGravity(Gravity.LEFT); toggleCard.addView(h);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView st=Ui.text(this,notificationAccess()?"Ready to monitor enabled WhatsApp apps":"Notification access is required",13);
        row.addView(st,new LinearLayout.LayoutParams(0,-2,1)); Switch sw=new Switch(this); sw.setChecked(RuleStore.autoReplyEnabled(this)); row.addView(sw); toggleCard.addView(row);
        sw.setOnCheckedChangeListener((b,checked)->RuleStore.setAutoReplyEnabled(this,checked));
        LinearLayout.LayoutParams tcp=new LinearLayout.LayoutParams(-1,-2); tcp.topMargin=Ui.dp(this,14); r.addView(toggleCard,tcp);

        StatsStore.Snapshot snap=StatsStore.snapshot(this); List<Rule> rules=RuleStore.load(this);
        LinearLayout statRow1=new LinearLayout(this);statRow1.setOrientation(LinearLayout.HORIZONTAL);statRow1.setWeightSum(2);
        statRow1.addView(statCard("Messages Today",String.valueOf(snap.detectedToday)),statParams(true));
        statRow1.addView(statCard("Replies Today",String.valueOf(snap.repliedToday)),statParams(false));
        LinearLayout.LayoutParams sr1p=new LinearLayout.LayoutParams(-1,-2);sr1p.topMargin=Ui.dp(this,12);r.addView(statRow1,sr1p);
        LinearLayout statRow2=new LinearLayout(this);statRow2.setOrientation(LinearLayout.HORIZONTAL);statRow2.setWeightSum(2);
        int activeRules=0;for(Rule rule:rules)if(rule.active)activeRules++;
        statRow2.addView(statCard("Active Rules",String.valueOf(activeRules)),statParams(true));
        statRow2.addView(statCard("Access",notificationAccess()?"ON":"OFF"),statParams(false));
        LinearLayout.LayoutParams sr2p=new LinearLayout.LayoutParams(-1,-2);sr2p.topMargin=Ui.dp(this,8);r.addView(statRow2,sr2p);

        Button create=Ui.button(this,"＋  Create Auto Reply"); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,Ui.dp(this,58)); cp.topMargin=Ui.dp(this,18); r.addView(create,cp);
        create.setOnClickListener(v->startActivity(new Intent(this,RuleActivity.class)));

        addAction(r,"⚙  My Rules",rules.size()+" saved • tap a rule to edit",v->renderRules());
        addAction(r,"↻  History","See successful automatic replies",v->renderHistory());
        addAction(r,"▥  Statistics","Performance and safety counters",v->renderStatistics());
        addAction(r,"☰  Settings","WhatsApp apps, permissions, backup and privacy",v->renderSettings());
        addAction(r,"♡  About & Support","Meet Martin Foli • support the free project",v->renderAbout());

        TextView foot=Ui.text(this,"Built with ❤️ in Ghana 🇬🇭  •  Sena Reply v1.1.0",12);foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=Ui.dp(this,24);r.addView(foot,fp);
    }

    private LinearLayout.LayoutParams statParams(boolean left){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);
        if(left)p.rightMargin=Ui.dp(this,4);else p.leftMargin=Ui.dp(this,4);return p;
    }

    private String greeting(){int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);return h<12?"Good morning":h<17?"Good afternoon":"Good evening";}

    private LinearLayout statCard(String label,String value) {
        LinearLayout c=Ui.cardLayout(this); TextView v=Ui.title(this,value,23); c.addView(v);TextView l=Ui.text(this,label,12);l.setGravity(Gravity.CENTER);c.addView(l);return c;
    }

    private void addAction(LinearLayout r,String title,String sub,View.OnClickListener click) {
        LinearLayout c=Ui.cardLayout(this); TextView t=Ui.title(this,title,17); t.setGravity(Gravity.LEFT); c.addView(t);
        TextView s=Ui.text(this,sub,13); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.dp(this,6);c.addView(s,sp);
        if(click!=null){c.setOnClickListener(click);c.setClickable(true);}
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,10);r.addView(c,cp);
    }

    private void renderRules() {
        currentScreen="rules"; LinearLayout r=root("My Rules"); List<Rule> rules=RuleStore.load(this);
        if(rules.isEmpty()){TextView e=Ui.text(this,"No rules yet. Create your first auto reply.",15);e.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=Ui.dp(this,35);r.addView(e,p);}
        for(Rule rule:rules){
            LinearLayout c=Ui.cardLayout(this);
            LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
            TextView t=Ui.title(this,"any".equals(rule.matchType)?"Any message":rule.trigger,17);t.setGravity(Gravity.LEFT);head.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Switch rs=new Switch(this);rs.setChecked(rule.active);head.addView(rs);c.addView(head);
            c.addView(Ui.text(this,matchLabel(rule.matchType)+"  →  "+preview(rule.reply,90),13));
            String scope="everyone".equals(rule.scope)?"Everyone":"contacts".equals(rule.scope)?"Individual contacts":"Groups";
            String schedule=rule.scheduleEnabled?" • Scheduled":"";c.addView(Ui.text(this,scope+" • "+rule.cooldownSeconds+"s cooldown"+schedule,12));
            rs.setOnCheckedChangeListener((b,on)->{Rule x=RuleStore.find(this,rule.id);if(x!=null){x.active=on;RuleStore.upsert(this,x);}});
            c.setOnClickListener(v->{Intent i=new Intent(this,RuleActivity.class);i.putExtra("rule_id",rule.id);startActivity(i);});c.setClickable(true);
            Button del=Ui.secondaryButton(this,"Delete");LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,Ui.dp(this,44));dp.topMargin=Ui.dp(this,10);c.addView(del,dp);
            del.setOnClickListener(v->confirmDelete(rule));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,10);r.addView(c,cp);
        }
        Button plus=Ui.button(this,"＋  New Rule");LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,Ui.dp(this,56));pp.topMargin=Ui.dp(this,18);r.addView(plus,pp);plus.setOnClickListener(v->startActivity(new Intent(this,RuleActivity.class)));
    }

    private String matchLabel(String m){if("starts".equals(m))return"STARTS WITH";if("ends".equals(m))return"ENDS WITH";if("wildcard".equals(m))return"WILDCARD";if("regex".equals(m))return"REGEX";if("any".equals(m))return"ANY";return m.toUpperCase();}
    private String preview(String s,int max){if(s==null)return"";return s.length()<=max?s:s.substring(0,max-1)+"…";}

    private void confirmDelete(Rule rule){new AlertDialog.Builder(this).setTitle("Delete rule?").setMessage("This cannot be undone.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{RuleStore.delete(this,rule.id);renderRules();}).show();}

    private void renderHistory() {
        currentScreen="history"; LinearLayout r=root("Reply History");
        JSONArray a=HistoryStore.load(this);
        Button clear=Ui.secondaryButton(this,"Clear History");LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,Ui.dp(this,46));clp.topMargin=Ui.dp(this,12);r.addView(clear,clp);
        clear.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Clear reply history?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{HistoryStore.clear(this);renderHistory();}).show());
        if(a.length()==0){TextView e=Ui.text(this,"No automatic replies have been sent yet.",15);e.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=Ui.dp(this,25);r.addView(e,p);return;}
        for(int i=0;i<a.length();i++){try{
            JSONObject o=a.getJSONObject(i);LinearLayout c=Ui.cardLayout(this);TextView s=Ui.title(this,o.optString("sender","WhatsApp"),17);s.setGravity(Gravity.LEFT);c.addView(s);
            String conv=o.optString("conversation","");String app=o.optString("app","WhatsApp");
            String meta=app+(conv.isEmpty()?"":" • "+conv);c.addView(Ui.text(this,meta,11));
            c.addView(Ui.text(this,"Received: "+o.optString("message")+"\nReplied: "+o.optString("reply")+"\n"+DateFormat.getDateTimeInstance().format(new Date(o.optLong("time"))),13));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,10);r.addView(c,cp);
        }catch(Exception ignored){}}
    }

    private void renderStatistics(){
        currentScreen="statistics";LinearLayout r=root("Statistics");StatsStore.Snapshot s=StatsStore.snapshot(this);
        addStatDetail(r,"Messages detected",s.detectedToday,s.detectedTotal,Ui.CYAN);
        addStatDetail(r,"Rules matched",s.matchedToday,s.matchedTotal,Ui.BLUE);
        addStatDetail(r,"Replies sent",s.repliedToday,s.repliedTotal,Ui.GREEN);
        addStatDetail(r,"Replies blocked by safety",s.blockedToday,s.blockedTotal,Ui.YELLOW);
        addStatDetail(r,"Reply attempts failed",s.failedToday,s.failedTotal,Ui.RED);
        TextView note=Ui.text(this,"Blocked replies include cooldown, loop protection, per-conversation hourly limits and the global safety cap.",12);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=Ui.dp(this,16);r.addView(note,np);
    }

    private void addStatDetail(LinearLayout r,String label,int today,long total,int color){LinearLayout c=Ui.cardLayout(this);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=Ui.title(this,label,16);t.setGravity(Gravity.LEFT);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));row.addView(Ui.status(this,String.valueOf(today)+" today",color));c.addView(row);TextView tot=Ui.text(this,"Total: "+total,13);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=Ui.dp(this,8);c.addView(tot,tp);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,10);r.addView(c,cp);}

    private void renderSettings(){
        currentScreen="settings";LinearLayout r=root("Settings");
        addToggle(r,"WhatsApp","Monitor the standard WhatsApp app",RuleStore.whatsappEnabled(this),(b,on)->RuleStore.setWhatsappEnabled(this,on));
        addToggle(r,"WhatsApp Business","Monitor WhatsApp Business",RuleStore.whatsappBusinessEnabled(this),(b,on)->RuleStore.setWhatsappBusinessEnabled(this,on));
        addToggle(r,"Store reply history","Keep successful reply history locally on this device",RuleStore.historyEnabled(this),(b,on)->RuleStore.setHistoryEnabled(this,on));
        addAction(r,"Notification Access",notificationAccess()?"Enabled ✓":"Required — tap to open Android settings",v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        addAction(r,"Battery Settings","Open Android battery optimization settings",v->startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)));
        addAction(r,"Export Backup","Save rules, history and key settings as a Sena Reply JSON backup",v->exportBackup());
        addAction(r,"Import Backup","Restore from a Sena Reply backup file",v->importBackup());
        addAction(r,"Reset Safety Counters","Clears recent reply-rate protection history only",v->{SafetyStore.clear(this);Toast.makeText(this,"Safety counters reset",Toast.LENGTH_SHORT).show();});
        TextView privacy=Ui.text(this,"Privacy: fixed-rule matching, history and statistics are processed locally. This build does not upload your WhatsApp messages to a Sena Reply server.",12);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.topMargin=Ui.dp(this,18);r.addView(privacy,pp);
    }

    private void addToggle(LinearLayout r,String title,String sub,boolean checked,android.widget.CompoundButton.OnCheckedChangeListener listener){LinearLayout c=Ui.cardLayout(this);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout text=new LinearLayout(this);text.setOrientation(LinearLayout.VERTICAL);TextView t=Ui.title(this,title,17);t.setGravity(Gravity.LEFT);text.addView(t);text.addView(Ui.text(this,sub,12));row.addView(text,new LinearLayout.LayoutParams(0,-2,1));Switch sw=new Switch(this);sw.setChecked(checked);sw.setOnCheckedChangeListener(listener);row.addView(sw);c.addView(row);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.dp(this,10);r.addView(c,cp);}

    private void renderAbout() {
        currentScreen="about";LinearLayout r=root("About & Support");
        ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.martin_foli);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(Ui.card(this));photo.setClipToOutline(true);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(Ui.dp(this,170),Ui.dp(this,170));ip.gravity=Gravity.CENTER_HORIZONTAL;ip.topMargin=Ui.dp(this,15);r.addView(photo,ip);
        TextView n=Ui.title(this,"Martin Foli",25);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=Ui.dp(this,14);r.addView(n,np);
        TextView roles=Ui.text(this,"Electrical/Electronic Engineer\nSelf-taught Programmer • Graphic Designer",14);roles.setGravity(Gravity.CENTER);r.addView(roles);
        addAction(r,"Developer Background","Graduate of Ho Technical University (HTU). Studied BSc Applied Technology at BYU–Idaho. Interested in practical technology, software and digital problem-solving.",null);
        addAction(r,"♡  Support via MTN MoMo — 0546757518","Sena Reply is free. Tap to copy the optional support number.",v->{copy("0546757518");Toast.makeText(this,"MoMo number copied",Toast.LENGTH_SHORT).show();});
        addAction(r,"✉  leeditgraphics@gmail.com","Tap to contact the developer",v->{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:leeditgraphics@gmail.com"));i.putExtra(Intent.EXTRA_SUBJECT,"Sena Reply Support");try{startActivity(i);}catch(Exception e){copy("leeditgraphics@gmail.com");}});
        TextView note=Ui.text(this,"Sena Reply is an independent Android utility and is not affiliated with, sponsored by or endorsed by WhatsApp or Meta.",12);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=Ui.dp(this,18);r.addView(note,p);
    }

    private void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"SenaReply-backup.json");startActivityForResult(i,REQ_EXPORT);}
    private void importBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,REQ_IMPORT);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        try{
            if(requestCode==REQ_EXPORT){String json=BackupStore.exportJson(this);OutputStream out=getContentResolver().openOutputStream(uri);if(out==null)throw new Exception("Cannot open destination");out.write(json.getBytes("UTF-8"));out.close();Toast.makeText(this,"Backup exported",Toast.LENGTH_SHORT).show();}
            else if(requestCode==REQ_IMPORT){InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new Exception("Cannot open backup");ByteArrayOutputStream bos=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)bos.write(buf,0,n);in.close();BackupStore.importJson(this,new String(bos.toByteArray(),"UTF-8"));Toast.makeText(this,"Backup restored",Toast.LENGTH_SHORT).show();renderSettings();}
        }catch(Exception e){Toast.makeText(this,"Backup error: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private boolean notificationAccess(){String flat=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");return flat!=null&&flat.contains(getPackageName());}
    private void copy(String value){ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("Sena Reply",value));}

    @Override public void onBackPressed(){if(!"dashboard".equals(currentScreen))renderDashboard();else super.onBackPressed();}
}
