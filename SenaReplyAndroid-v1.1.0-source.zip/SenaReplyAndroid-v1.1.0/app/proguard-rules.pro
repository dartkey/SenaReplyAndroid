# Sena Reply v1.0.0 - no custom ProGuard rules yet.
