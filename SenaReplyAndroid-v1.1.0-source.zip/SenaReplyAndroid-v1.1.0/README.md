# Sena Reply — Android v1.1.0

A local-first Android auto-reply utility for WhatsApp and WhatsApp Business.

**Developer:** Martin Foli  
**Contact:** leeditgraphics@gmail.com  
**Optional MTN MoMo support:** 0546757518  
**Package:** `com.leedit.senareply`

## What v1.1.0 includes

- Official Sena Reply icon, splash screen and blue glass UI
- First-run developer introduction and optional MoMo support screen
- Notification Listener onboarding
- Master Auto Reply switch
- WhatsApp and WhatsApp Business toggles
- Rule creation **and editing**
- Exact, contains, starts-with, ends-with, wildcard, regex and any-message matching
- Everyone / individual-contact / group targeting based on notification display names
- Optional exclusions
- Reply delay
- Per-conversation cooldown
- Per-conversation hourly limit
- Day/time scheduling, including overnight schedules
- Multiple random reply variants using `||`
- Persistent anti-loop and rate-limit safety controls
- Duplicate-notification suppression
- Local reply history
- Today + lifetime statistics
- JSON backup export/import through Android's Storage Access Framework
- About & Support screen with Martin's portrait, MoMo and email

## Important technical behavior

Sena Reply does **not** modify WhatsApp and does not require root. It listens for WhatsApp notifications with Android's `NotificationListenerService`, matches enabled rules locally, and sends a configured response through the notification's Android `RemoteInput` Reply action.

Contact/group matching uses the names exposed by the WhatsApp notification. This build intentionally does not request access to the user's phone contacts.

## Build in Android Studio

1. Open this folder in current Android Studio.
2. Let Gradle sync.
3. Build → Build APK(s).
4. Debug output is normally at `app/build/outputs/apk/debug/app-debug.apk`.

The project targets Android API 35 and uses minimum Android API 23.

## GitHub Actions build

`.github/workflows/build-apk.yml` builds a debug APK on a GitHub runner. Put this project in a repository, then run **Build Sena Reply APK** from Actions. The resulting artifact is named `SenaReply-v1.1.0-debug`.

## First install

1. Install the APK.
2. Complete Sena Reply onboarding.
3. Grant **Notification access** to Sena Reply.
4. On some sideloaded Android 13+ devices, Android may first require **App info → ⋮ → Allow restricted settings**.
5. Ensure WhatsApp notifications are enabled and include message content.
6. Create a simple rule such as `Hello` → `Hi! Thanks for messaging me.`
7. Test from a different WhatsApp account/device.

## Safety defaults

Each rule defaults to a 30-second cooldown and no more than 10 replies to the same conversation per hour. A separate global safety cap defaults to 120 replies/hour. Sena Reply also blocks a reply when an incoming message exactly repeats the app's most recent automated response for that conversation.

These protections reduce accidental reply loops; they do not guarantee that WhatsApp/Meta will permit every form of automation. Avoid spam, unsolicited bulk messaging and high-volume automation.

## Privacy

Fixed-rule processing, history, statistics and safety counters stay locally on the Android device. Version 1.1.0 contains no Sena Reply cloud message-processing backend.

Sena Reply is independent and is not affiliated with, sponsored by, or endorsed by WhatsApp or Meta.
